﻿namespace CostSplitterAPI.DTO
{
    public class UserDTO
    {
        public string Email { get; set; }

        public string Password { get; set; }
    }
}
